#!/bin/bash

# filtreaza log urile dupa un cuvant -- PRIMUL ARG E FISIERUL, AL DOILEA CUVANTUL
filter_logs() {
    FILE="$1"
    KEYWORD="$2"

    if [[ ! -f "$FILE" ]]; then
        echo "fisierul $FILE nu exista"
        return
    fi

    echo " Linii din $FILE care contin '$KEYWORD':"
    grep -i "$KEYWORD" "$FILE"
}


    filter_logs "$1" "$2"
