#!/bin/bash
DISTRO=$(grep -i '^ID=' /etc/os-release | cut -d= -f2 | tr -d '"')

# sa se afiseze distributia
echo " Distributia este: $DISTRO"

# DIRECTOR CENTRALIZARE LOGURI
BACKUP_DIR="$HOME/practica/loguri_centralizate"
mkdir -p "$BACKUP_DIR"

if [[ "$DISTRO" == "ubuntu" || "$DISTRO" == "linuxmint" ]]; then
    echo "Sistemul este compatibil "
    cp /var/log/syslog "$BACKUP_DIR/syslog.log" 2>/dev/null
    cp /var/log/auth.log "$BACKUP_DIR/auth.log" 2>/dev/null
    cp /var/log/wtmp "$BACKUP_DIR/wtmp.log" 2>/dev/null
    cp /var/log/apt/history.log "$BACKUP_DIR/apt_history.log" 2>/dev/null
elif [[ "$DISTRO" == "fedora" ]]; then
    echo "FEDORA"
    cp /var/log/messages "$BACKUP_DIR/messages.log" 2>/dev/null
    journalctl -u sshd > "$BACKUP_DIR/sshd.log" 2>/dev/null
    cp /var/log/wtmp "$BACKUP_DIR/wtmp.log" 2>/dev/null
    cp /var/log/dnf.rpm.log "$BACKUP_DIR/dnf_log.log" 2>/dev/null
else
    echo "EROARE."
    exit 1
fi

echo " Logurile au fost salvate: $BACKUP_DIR"

